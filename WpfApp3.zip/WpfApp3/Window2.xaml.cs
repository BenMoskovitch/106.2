﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Net.Http;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;
using static System.Reflection.Metadata.BlobBuilder;


namespace WpfApp3
{
    /*  public partial class Window2 : Window
      {

          public ObservableCollection<Book> Books { get; set; } = new ObservableCollection<Book>();

          public Window2()
          {
              InitializeComponent();
              string filePath = @"C:\Users\270427125\OneDrive - UP Education\Documents\WpfApp3\Books.csv";

              if (!File.Exists(filePath))
              {
                  MessageBox.Show("File not found: " + filePath);
              }
              else
              {
                  LoadBooksFromFile(filePath);
              }

              DataContext = this; // Set the DataContext for data binding
          }

          private void LoadBooksFromFile(string filePath)
          {
              if (File.Exists(filePath))
              {
                  var lines = File.ReadAllLines(filePath).Skip(1); // Skip header row
                  foreach (var line in lines)
                  {
                      var parts = line.Split(',');
                      if (parts.Length == 5)
                      {
                          Books.Add(new Book
                          {
                              BookName = parts[0],
                              Author = parts[1],
                              PageNumber = int.Parse(parts[2]),
                              Description = parts[3],
                              ImageLink = parts[4]
                          });
                      }
                  }
              }
          }

          private void Button_Click(object sender, RoutedEventArgs e)
          {
              Window3 window3 = new Window3();
              window3.Show();
              this.Close();
          }

          private void Button_Click_1(object sender, RoutedEventArgs e)
          {
              Window4 window4 = new Window4();
              window4.Show();
              this.Close();
          }
      }
  }
    */

        public partial class Window2 : Window
        {
            public ObservableCollection<Book> Books { get; set; } = new ObservableCollection<Book>();

            public Window2()
            {
                InitializeComponent();
                DataContext = this; // Set DataContext for binding

                string filePath = @"C:\Users\270427125\OneDrive - UP Education\Documents\WpfApp3\Books.csv";

                if (File.Exists(filePath))
                {
                    LoadBooksFromFile(filePath);
                }
                else
                {
                    MessageBox.Show("CSV file not found: " + filePath);
                }
            }

            private async void LoadBooksFromFile(string filePath)
            {
                var lines = File.ReadAllLines(filePath).Skip(1); // Skip header row
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 5 && int.TryParse(parts[2], out int pageNumber))
                    {
                        var bookImage = await GetImageFromUrl(parts[4]);
                        Books.Add(new Book
                        {
                            BookName = parts[0],
                            Author = parts[1],
                            PageNumber = pageNumber,
                            Description = parts[3],
                            ImageLink = parts[4],
                            BookImage = bookImage
                        });
                    }
                }
            }

            private async Task<BitmapImage> GetImageFromUrl(string url)
            {
                try
                {
                    using (var httpClient = new HttpClient())
                    {
                        var response = await httpClient.GetAsync(url);
                        if (response.IsSuccessStatusCode)
                        {
                            using (var stream = await response.Content.ReadAsStreamAsync())
                            {
                                var bitmap = new BitmapImage();
                                bitmap.BeginInit();
                                bitmap.StreamSource = stream;
                                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                                bitmap.EndInit();
                                return bitmap;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to load image: {ex.Message}");
                }
                return null;
            }

            private void EditBook_Click(object sender, RoutedEventArgs e)
            {
                var selectedBook = (sender as MenuItem)?.DataContext as Book;
                if (selectedBook != null)
                {
                    MessageBox.Show($"Editing book: {selectedBook.BookName}");
                }
            }

            private void DeleteBook_Click(object sender, RoutedEventArgs e)
            {
                var selectedBook = (sender as MenuItem)?.DataContext as Book;
                if (selectedBook != null)
                {
                    Books.Remove(selectedBook);
                    MessageBox.Show($"Deleted book: {selectedBook.BookName}");
                }
            }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            // Show Window3
            window2.Show();
            // Optionally, close the MainWindow if you want only one window open at a time
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4();
            // Show Window3
            window4.Show();
            // Optionally, close the MainWindow if you want only one window open at a time
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3();
            // Show Window3
            window3.Show();
            // Optionally, close the MainWindow if you want only one window open at a time
            this.Close();
        }
    }
    }