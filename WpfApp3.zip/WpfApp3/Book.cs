﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace WpfApp3
{

        public class Book
        {
            public string? BookName { get; set; }
            public string? Author { get; set; }
            public int PageNumber { get; set; }
            public string? Description { get; set; }
            public string? ImageLink { get; set; }
        public BitmapImage? BookImage { get; set; }
    }
        }

