﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login(object sender, RoutedEventArgs e)
        {

            string username = username_text.Text;
            string password = password_text.Password;

            if (ValidateUserLogin(username, password))
            {
                // MessageBox.Show("Login successful!");
                // Proceed to the next window or functionality
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        private bool ValidateUserLogin(string username, string password)
        {

            try
            {
                string filePath = @"C:\Users\270427125\OneDrive - UP Education\Documents\WpfApp3\User.csv";
                // Check if the file exists
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("File not found: " + filePath);
                    return false;
                }
                // Read CSV file
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines.Skip(1)) // Skip header row
                {
                    var values = line.Split(',');
                    if (values[0] == username && values[1] == password)
                    {
                        Window2 window2 = new Window2();
                        // Show Window3
                        window2.Show();
                        // Optionally, close the MainWindow if you want only one window open at a time
                        this.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the admin file: " + ex.Message);
            }

            return false;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of Window3
            Window1 window1 = new Window1();
            // Show Window3
            window1.Show();
            // Optionally, close the MainWindow if you want only one window open at a time
            this.Close();
        }
    }
}
